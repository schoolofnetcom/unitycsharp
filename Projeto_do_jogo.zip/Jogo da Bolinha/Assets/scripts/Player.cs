﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Player : MonoBehaviour {

	private Rigidbody esferaMove;
	public float velocidade = 10;
	public Text pontosExibe;


	int pontos;

	void Start () {
		esferaMove = GetComponent<Rigidbody> ();
		pontos = 0;
		AtualizarOContador ();
	}
	
	void LateUpdate(){
	 
		float posicaoHorizontal = Input.GetAxis ("Horizontal");
		float posicaoVertical = Input.GetAxis ("Vertical");

		Vector3 movimento = new Vector3 (posicaoHorizontal,0.0f,posicaoVertical);

		esferaMove.AddForce (movimento*velocidade);
	   	 
	}
 
	void OnTriggerEnter(Collider outroObjeto){
	  
		if (outroObjeto.gameObject.CompareTag ("PontosCubos")) {
			outroObjeto.gameObject.SetActive (false);
			pontos += 1;
			AtualizarOContador ();
		}
	}


	void AtualizarOContador(){
	
		pontosExibe.text = "Pontos:" + pontos.ToString ();

	}

}
