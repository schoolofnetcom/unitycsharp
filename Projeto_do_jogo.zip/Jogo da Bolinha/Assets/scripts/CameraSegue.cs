﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraSegue : MonoBehaviour {

	public GameObject esfera;
	private Vector3 distancia;


	void Start () {
		distancia = transform.position - esfera.transform.position; 
	}

	void LateUpdate () {
		transform.position = esfera.transform.position + distancia;
	}
}
