﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class arrays : MonoBehaviour {
	// Maneira errada
	/*string jogador1 = "Victor";
	string jogador2 = "Batatinha";
	string jogador3 = "Laranja mecanica";
	string jogador4 = "Who";*/

	// maneira correta

	string[] jogadores = { "Victor", "Batatinha", "Laranja Mecanica", "Who" };

	// Use this for initialization
	void Start () {

		print (jogadores [2]);

	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
