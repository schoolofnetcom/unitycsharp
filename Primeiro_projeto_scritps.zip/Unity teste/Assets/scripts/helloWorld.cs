﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class helloWorld : MonoBehaviour {

	// Use this for initialization

	void Start () {

		string nome = "Victor";
		string armaEquipada = "Manopla";
		string classe = "Lutador";
		string pais = "Terra Media";

		Debug.Log (nome);
		Debug.Log (armaEquipada);
		Debug.Log (classe);
		Debug.Log (pais);


		float vida = 100;
		float armadura = 45.5f;
		float danoEspada = 60;
		double vidaAtual = (double)vida;
		vidaAtual -= danoEspada - (armadura * 0.50);
		Debug.Log (vidaAtual);
	

	}
	
	// Update is called once per frame
	void Update () {
		
	}

}
