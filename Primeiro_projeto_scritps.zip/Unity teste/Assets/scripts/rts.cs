﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class rts : MonoBehaviour {

	public string civPlayer1 = "Romanos";
	public string civPlayer2 = "Teutonicos";

	bool torrePrincipalP1Destruida = false;
	bool torrePrincipalP2Destruida = false;

	int torresRestantesP1 = 3;
	int torresRestantesP2 = 1;

	int tempo = 0;

	// Use this for initialization
	void Start () {

		if (torrePrincipalP1Destruida == true || torrePrincipalP2Destruida == true) {

			if (torrePrincipalP1Destruida == true) {
				print ("Os " + civPlayer2 + " Venceram a partida ");
			} else {
				print ("Os " + civPlayer1 + " Venceram a Partida");
			}

		} else if (tempo <= 0) {

			if (torresRestantesP1 < torresRestantesP2) {
				print ("Os " + civPlayer2 + " Venceram a partida ");
			} else {
				print ("Os " + civPlayer1 + " Venceram a Partida");
			}

		} else {
		  
			print ("O Jogo empatou");
		
		}
	}		
	
	// Update is called once per frame
	void Update () {
		
	}
}
