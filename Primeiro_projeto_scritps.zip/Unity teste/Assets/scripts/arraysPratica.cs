﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class arraysPratica : MonoBehaviour {

	public GameObject esferaPrefab;

	GameObject[] esferas = new GameObject[9]; 

	// Use this for initialization
	void Start () {

		for(int i = 0; i < esferas.Length;i++){

			GameObject esfera = Instantiate (esferaPrefab);
			esferas[i] = esfera;
			esfera.transform.position = new Vector3 (i*2.0f,esfera.transform.position.y); 

		}


	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
