﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SistemaDeBatalha : MonoBehaviour {
    
	int vida = 100;
	int ataqueEspada = 30;

	public void Atacar(){
	
		vida -= ataqueEspada;
		print ("Você foi atacado, e sua vida atual eh " + vida);

	}
		
	public void Curar(){
	
		int vidaCurada = numeroAleatorio ();
		vida += vidaCurada;
		print ("Você foi curado em " + vidaCurada + " Pontos de vida");
		print ("E sua vida atual eh " + vida);
	
	}

	int numeroAleatorio(){
		return Random.Range (1,40);
	}

}
