﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameOver : MonoBehaviour {

	int vida = -10;
	bool gameOver = false;
	// Use this for initialization
	void Start () {


		if(vida <= 0){
			gameOver = true;
		}

		if (gameOver == true) {
			print ("O Jogo acabou para você");
		} else {
			print ("Jogo que segue");
		}

	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
